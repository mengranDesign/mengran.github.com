window.__imported__ = window.__imported__ || {};
window.__imported__["currentR@2x/layers.json.js"] = [
	{
		"objectId": "FFC43432-1FF2-4E18-A9A6-45AB167AD02C",
		"kind": "artboard",
		"name": "studentPage",
		"originalName": "studentPage",
		"maskFrame": null,
		"layerFrame": {
			"x": 12660,
			"y": 11825,
			"width": 1440,
			"height": 1840
		},
		"visible": true,
		"metadata": {},
		"backgroundColor": "rgba(245, 245, 245, 1)",
		"children": [
			{
				"objectId": "22223534-DE9E-49EE-8B35-4E799E8BA6B8",
				"kind": "group",
				"name": "content1",
				"originalName": "content1",
				"maskFrame": null,
				"layerFrame": {
					"x": -1,
					"y": -2,
					"width": 1442,
					"height": 1842
				},
				"visible": true,
				"metadata": {
					"opacity": 1
				},
				"children": [
					{
						"objectId": "EB9DEB77-19D3-4953-8D41-E8960D76ECB1",
						"kind": "group",
						"name": "header1",
						"originalName": "header1*",
						"maskFrame": null,
						"layerFrame": {
							"x": -1,
							"y": -2,
							"width": 1442,
							"height": 326
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-header1-rui5revc.jpg",
							"frame": {
								"x": -1,
								"y": -2,
								"width": 1442,
								"height": 326
							}
						},
						"children": []
					},
					{
						"objectId": "AF6291A9-4393-4E54-B84D-29FAF259A957",
						"kind": "text",
						"name": "resLine1",
						"originalName": "resLine1",
						"maskFrame": null,
						"layerFrame": {
							"x": 589,
							"y": 358,
							"width": 116,
							"height": 15
						},
						"visible": true,
						"metadata": {
							"opacity": 1,
							"string": "Research Line",
							"css": [
								"/* Research Line: */",
								"opacity: 0.5;",
								"font-family: .HelveticaNeueDeskInterface-Regular;",
								"font-size: 18px;",
								"color: #000000;",
								"letter-spacing: 0;"
							]
						},
						"image": {
							"path": "images/Layer-resLine1-quy2mjkx.png",
							"frame": {
								"x": 589,
								"y": 358,
								"width": 116,
								"height": 15
							}
						},
						"children": []
					},
					{
						"objectId": "FA470140-8C28-42DA-9697-EE608F5B065C",
						"kind": "text",
						"name": "overveiw1",
						"originalName": "overveiw1",
						"maskFrame": null,
						"layerFrame": {
							"x": 230,
							"y": 356,
							"width": 76,
							"height": 16
						},
						"visible": true,
						"metadata": {
							"opacity": 1,
							"string": "Overview",
							"css": [
								"/* Overview: */",
								"opacity: 0.5;",
								"font-family: .HelveticaNeueDeskInterface-Regular;",
								"font-size: 18px;",
								"color: #000000;",
								"letter-spacing: 0;"
							]
						},
						"image": {
							"path": "images/Layer-overveiw1-rke0nzax.png",
							"frame": {
								"x": 230,
								"y": 356,
								"width": 76,
								"height": 16
							}
						},
						"children": []
					},
					{
						"objectId": "53D7A229-E30F-418F-88DC-6E08BCAAAEF0",
						"kind": "group",
						"name": "tabBar1",
						"originalName": "tabBar1*",
						"maskFrame": null,
						"layerFrame": {
							"x": 0,
							"y": 324,
							"width": 1440,
							"height": 81
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-tabBar1-ntnen0ey.png",
							"frame": {
								"x": 0,
								"y": 324,
								"width": 1440,
								"height": 81
							}
						},
						"children": []
					},
					{
						"objectId": "B6A14AD4-B34B-478E-94A9-7E5201468003",
						"kind": "group",
						"name": "btn_currentRes",
						"originalName": "btn_currentRes",
						"maskFrame": null,
						"layerFrame": {
							"x": 246,
							"y": 769,
							"width": 207,
							"height": 87
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-btn_currentRes-qjzbmtrb.png",
							"frame": {
								"x": 246,
								"y": 769,
								"width": 207,
								"height": 87
							}
						},
						"children": []
					},
					{
						"objectId": "F32CF255-4DED-4064-9FDD-C28E0C67704D",
						"kind": "group",
						"name": "btn_newRes",
						"originalName": "btn_newRes",
						"maskFrame": null,
						"layerFrame": {
							"x": 246,
							"y": 876,
							"width": 124,
							"height": 14
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-btn_newRes-rjmyq0yy.png",
							"frame": {
								"x": 246,
								"y": 876,
								"width": 124,
								"height": 14
							}
						},
						"children": []
					},
					{
						"objectId": "7F3697F9-80E9-4242-8A21-4F6EFFABF054",
						"kind": "group",
						"name": "cards",
						"originalName": "cards*",
						"maskFrame": null,
						"layerFrame": {
							"x": 0,
							"y": 0,
							"width": 1440,
							"height": 1840
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-cards-n0yznjk3.jpg",
							"frame": {
								"x": 0,
								"y": 0,
								"width": 1440,
								"height": 1840
							}
						},
						"children": []
					}
				]
			}
		]
	},
	{
		"objectId": "7DAE274C-E1A6-4C94-A1F6-5F65F48FD192",
		"kind": "artboard",
		"name": "newResLine_addM",
		"originalName": "newResLine_addM",
		"maskFrame": null,
		"layerFrame": {
			"x": 17553,
			"y": 11825,
			"width": 1440,
			"height": 1754
		},
		"visible": true,
		"metadata": {},
		"backgroundColor": "rgba(245, 245, 245, 1)",
		"children": [
			{
				"objectId": "893B37C6-F19B-48D2-9E72-BAF9D81BD5C4",
				"kind": "group",
				"name": "content6",
				"originalName": "content6",
				"maskFrame": null,
				"layerFrame": {
					"x": -1,
					"y": -2,
					"width": 1443,
					"height": 1748
				},
				"visible": true,
				"metadata": {
					"opacity": 1
				},
				"children": [
					{
						"objectId": "76141804-E388-433F-A44C-910196DDB3A0",
						"kind": "group",
						"name": "Mentor_picture",
						"originalName": "Mentor picture",
						"maskFrame": {
							"x": 0,
							"y": 0,
							"width": 160,
							"height": 160
						},
						"layerFrame": {
							"x": 255,
							"y": 101,
							"width": 160,
							"height": 160
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-Mentor_picture-nzyxnde4.png",
							"frame": {
								"x": 255,
								"y": 101,
								"width": 160,
								"height": 160
							}
						},
						"children": []
					},
					{
						"objectId": "8F92D7CF-516C-44B5-9620-02E7767FDA59",
						"kind": "group",
						"name": "uploadBox",
						"originalName": "uploadBox",
						"maskFrame": null,
						"layerFrame": {
							"x": 588,
							"y": 1152,
							"width": 708,
							"height": 367
						},
						"visible": false,
						"metadata": {
							"opacity": 1
						},
						"children": [
							{
								"objectId": "3856F5A6-906A-420C-9FD2-CEF0AC028534",
								"kind": "group",
								"name": "uploadClose",
								"originalName": "uploadClose",
								"maskFrame": null,
								"layerFrame": {
									"x": 1233,
									"y": 1198,
									"width": 14,
									"height": 14
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-uploadClose-mzg1nky1.png",
									"frame": {
										"x": 1233,
										"y": 1198,
										"width": 14,
										"height": 14
									}
								},
								"children": []
							},
							{
								"objectId": "176A22CE-26FA-4310-B292-44635B3D6C15",
								"kind": "group",
								"name": "uploadBoxBu",
								"originalName": "uploadBoxBu",
								"maskFrame": null,
								"layerFrame": {
									"x": 821,
									"y": 1344,
									"width": 226,
									"height": 24
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-uploadBoxBu-mtc2qtiy.png",
									"frame": {
										"x": 821,
										"y": 1344,
										"width": 226,
										"height": 24
									}
								},
								"children": [
									{
										"objectId": "961CF85E-5BC7-4670-B973-777F4125C92E",
										"kind": "group",
										"name": "gizmo_upload",
										"originalName": "gizmo-upload",
										"maskFrame": null,
										"layerFrame": {
											"x": 821,
											"y": 1344,
											"width": 27,
											"height": 23
										},
										"visible": true,
										"metadata": {
											"opacity": 1
										},
										"image": {
											"path": "images/Layer-gizmo_upload-otyxq0y4.png",
											"frame": {
												"x": 821,
												"y": 1344,
												"width": 27,
												"height": 23
											}
										},
										"children": []
									}
								]
							},
							{
								"objectId": "5E31DDA5-EB05-4F3A-90E9-44C70FBFCB33",
								"kind": "group",
								"name": "uploadOth",
								"originalName": "uploadOth",
								"maskFrame": null,
								"layerFrame": {
									"x": 588,
									"y": 1152,
									"width": 707,
									"height": 366
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-uploadOth-nuuzmure.png",
									"frame": {
										"x": 588,
										"y": 1152,
										"width": 707,
										"height": 366
									}
								},
								"children": []
							}
						]
					},
					{
						"objectId": "3462FFD8-52B5-402E-B2F4-D5CC1233A3BC",
						"kind": "group",
						"name": "meetingWindow",
						"originalName": "meetingWindow",
						"maskFrame": null,
						"layerFrame": {
							"x": 366,
							"y": 771,
							"width": 715,
							"height": 625
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"children": [
							{
								"objectId": "6DAE938E-8356-4BA9-B5E8-B28D79E8904B",
								"kind": "group",
								"name": "btn_cancel_meeting",
								"originalName": "btn_cancel_meeting",
								"maskFrame": null,
								"layerFrame": {
									"x": 414,
									"y": 1327,
									"width": 106,
									"height": 40
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-btn_cancel_meeting-nkrbrtkz.png",
									"frame": {
										"x": 414,
										"y": 1327,
										"width": 106,
										"height": 40
									}
								},
								"children": []
							},
							{
								"objectId": "C5A07C39-CAE5-4058-8FBE-2D473BD69A71",
								"kind": "group",
								"name": "btn_confirm_meeting",
								"originalName": "btn_confirm_meeting",
								"maskFrame": null,
								"layerFrame": {
									"x": 924,
									"y": 1327,
									"width": 106,
									"height": 40
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-btn_confirm_meeting-qzvbmddd.png",
									"frame": {
										"x": 924,
										"y": 1327,
										"width": 106,
										"height": 40
									}
								},
								"children": []
							},
							{
								"objectId": "380FB13D-7BF6-4BD3-8513-AEE527A74D5E",
								"kind": "group",
								"name": "addAttendees",
								"originalName": "addAttendees",
								"maskFrame": null,
								"layerFrame": {
									"x": 886,
									"y": 975,
									"width": 26,
									"height": 19
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"children": [
									{
										"objectId": "22D33466-8D47-46FE-8DC2-C27D5C876936",
										"kind": "group",
										"name": "gizmo_couple_of_people",
										"originalName": "gizmo-couple-of-people",
										"maskFrame": null,
										"layerFrame": {
											"x": 886,
											"y": 975,
											"width": 26,
											"height": 19
										},
										"visible": true,
										"metadata": {
											"opacity": 1
										},
										"image": {
											"path": "images/Layer-gizmo_couple_of_people-mjjemzm0.png",
											"frame": {
												"x": 886,
												"y": 975,
												"width": 26,
												"height": 19
											}
										},
										"children": []
									}
								]
							},
							{
								"objectId": "7B62145A-D259-4454-9E06-8AB5E331C27C",
								"kind": "group",
								"name": "addDocumentM",
								"originalName": "addDocumentM",
								"maskFrame": null,
								"layerFrame": {
									"x": 842,
									"y": 974,
									"width": 21,
									"height": 21
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-addDocumentM-n0i2mje0.png",
									"frame": {
										"x": 842,
										"y": 974,
										"width": 21,
										"height": 21
									}
								},
								"children": []
							},
							{
								"objectId": "A86118EF-2AF1-408B-BAE9-29235A66B4B1",
								"kind": "group",
								"name": "InviteB",
								"originalName": "InviteB",
								"maskFrame": null,
								"layerFrame": {
									"x": 706,
									"y": 1037,
									"width": 438,
									"height": 207
								},
								"visible": false,
								"metadata": {
									"opacity": 1
								},
								"children": [
									{
										"objectId": "06E77ED9-7882-47D0-83C8-E18DBEAC11F6",
										"kind": "group",
										"name": "attendBoxCancel",
										"originalName": "attendBoxCancel",
										"maskFrame": null,
										"layerFrame": {
											"x": 882,
											"y": 1187,
											"width": 87,
											"height": 16
										},
										"visible": true,
										"metadata": {
											"opacity": 1
										},
										"image": {
											"path": "images/Layer-attendBoxCancel-mdzfnzdf.png",
											"frame": {
												"x": 882,
												"y": 1187,
												"width": 87,
												"height": 16
											}
										},
										"children": []
									},
									{
										"objectId": "9EE942F7-2FC2-4EDC-A653-8E7B8B4F20A5",
										"kind": "group",
										"name": "attendBoxContinue",
										"originalName": "attendBoxContinue",
										"maskFrame": null,
										"layerFrame": {
											"x": 1004,
											"y": 1187,
											"width": 93,
											"height": 19
										},
										"visible": true,
										"metadata": {
											"opacity": 1
										},
										"image": {
											"path": "images/Layer-attendBoxContinue-ouvfotqy.png",
											"frame": {
												"x": 1004,
												"y": 1187,
												"width": 93,
												"height": 19
											}
										},
										"children": []
									},
									{
										"objectId": "31C74E02-2B99-4EDE-A5C6-5AF75115EF7A",
										"kind": "group",
										"name": "inviteClose",
										"originalName": "inviteClose",
										"maskFrame": null,
										"layerFrame": {
											"x": 1094,
											"y": 1071,
											"width": 14,
											"height": 14
										},
										"visible": true,
										"metadata": {
											"opacity": 1
										},
										"image": {
											"path": "images/Layer-inviteClose-mzfdnzrf.png",
											"frame": {
												"x": 1094,
												"y": 1071,
												"width": 14,
												"height": 14
											}
										},
										"children": []
									},
									{
										"objectId": "DB72B0C5-505D-4EA9-8F63-EE0F48C86195",
										"kind": "text",
										"name": "inviteFill",
										"originalName": "inviteFill",
										"maskFrame": null,
										"layerFrame": {
											"x": 760,
											"y": 1127,
											"width": 234,
											"height": 21
										},
										"visible": false,
										"metadata": {
											"opacity": 1,
											"string": "chester.r@gmail.com",
											"css": [
												"/* chester.r@gmail.com: */",
												"font-family: HelveticaNeue;",
												"font-size: 18px;",
												"color: #505050;"
											]
										},
										"image": {
											"path": "images/Layer-inviteFill-rei3mkiw.png",
											"frame": {
												"x": 760,
												"y": 1127,
												"width": 234,
												"height": 21
											}
										},
										"children": []
									},
									{
										"objectId": "4D782B29-B4A5-407B-8B83-B0B966E3C72D",
										"kind": "group",
										"name": "inviteNo",
										"originalName": "inviteNo",
										"maskFrame": null,
										"layerFrame": {
											"x": 763,
											"y": 1124,
											"width": 127,
											"height": 28
										},
										"visible": true,
										"metadata": {
											"opacity": 1
										},
										"image": {
											"path": "images/Layer-inviteNo-neq3odjc.png",
											"frame": {
												"x": 763,
												"y": 1124,
												"width": 127,
												"height": 28
											}
										},
										"children": []
									},
									{
										"objectId": "6D049C12-2B0C-465B-A1E1-9CA0388DBFA3",
										"kind": "group",
										"name": "inviteOther",
										"originalName": "inviteOther",
										"maskFrame": null,
										"layerFrame": {
											"x": 706,
											"y": 1037,
											"width": 437,
											"height": 207
										},
										"visible": true,
										"metadata": {
											"opacity": 1
										},
										"image": {
											"path": "images/Layer-inviteOther-nkqwndld.png",
											"frame": {
												"x": 706,
												"y": 1037,
												"width": 437,
												"height": 207
											}
										},
										"children": []
									}
								]
							},
							{
								"objectId": "4E938555-B1EC-400C-833D-0EDCEB7A9C4B",
								"kind": "group",
								"name": "attendeeF",
								"originalName": "attendeeF",
								"maskFrame": null,
								"layerFrame": {
									"x": 446,
									"y": 1083,
									"width": 168,
									"height": 18
								},
								"visible": false,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-attendeeF-neu5mzg1.png",
									"frame": {
										"x": 446,
										"y": 1083,
										"width": 168,
										"height": 18
									}
								},
								"children": []
							},
							{
								"objectId": "55203729-D1CD-4C05-988F-CE3F83B685AF",
								"kind": "group",
								"name": "meetingDocument",
								"originalName": "meetingDocument*",
								"maskFrame": null,
								"layerFrame": {
									"x": 460,
									"y": 1150,
									"width": 71,
									"height": 94
								},
								"visible": false,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-meetingDocument-ntuymdm3.png",
									"frame": {
										"x": 460,
										"y": 1150,
										"width": 71,
										"height": 94
									}
								},
								"children": []
							},
							{
								"objectId": "35CCCDCB-CD24-4B69-BF6F-2F2C2B0ECD63",
								"kind": "group",
								"name": "meetingBox",
								"originalName": "meetingBox",
								"maskFrame": null,
								"layerFrame": {
									"x": 366,
									"y": 850,
									"width": 715,
									"height": 546
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"children": [
									{
										"objectId": "A1AA59BA-E2E4-479D-BBB7-1D835DCD0396",
										"kind": "group",
										"name": "meetingBClose",
										"originalName": "meetingBClose",
										"maskFrame": null,
										"layerFrame": {
											"x": 1047,
											"y": 866,
											"width": 16,
											"height": 17
										},
										"visible": true,
										"metadata": {
											"opacity": 1
										},
										"image": {
											"path": "images/Layer-meetingBClose-qtfbqtu5.png",
											"frame": {
												"x": 1047,
												"y": 866,
												"width": 16,
												"height": 17
											}
										},
										"children": []
									},
									{
										"objectId": "6AE0862B-5B10-4FB5-988C-CB6421E4A482",
										"kind": "group",
										"name": "titleNoM",
										"originalName": "titleNoM",
										"maskFrame": null,
										"layerFrame": {
											"x": 649,
											"y": 873,
											"width": 141,
											"height": 24
										},
										"visible": true,
										"metadata": {
											"opacity": 1
										},
										"image": {
											"path": "images/Layer-titleNoM-nkffmdg2.png",
											"frame": {
												"x": 649,
												"y": 873,
												"width": 141,
												"height": 24
											}
										},
										"children": []
									},
									{
										"objectId": "810BCE59-950F-435C-AD94-D8F7C7BC091A",
										"kind": "text",
										"name": "titleFillM",
										"originalName": "titleFillM",
										"maskFrame": null,
										"layerFrame": {
											"x": 647,
											"y": 873,
											"width": 195,
											"height": 21
										},
										"visible": false,
										"metadata": {
											"opacity": 1,
											"string": "First Experiment Report",
											"css": [
												"/* First Experiment Rep: */",
												"font-family: HelveticaNeue;",
												"font-size: 18px;",
												"color: #9B9B9B;"
											]
										},
										"image": {
											"path": "images/Layer-titleFillM-odewqknf.png",
											"frame": {
												"x": 647,
												"y": 873,
												"width": 195,
												"height": 21
											}
										},
										"children": []
									},
									{
										"objectId": "635F5A70-0EDB-4B3F-9E67-D38AB67C2B18",
										"kind": "group",
										"name": "contentNoM",
										"originalName": "contentNoM",
										"maskFrame": null,
										"layerFrame": {
											"x": 447,
											"y": 1028,
											"width": 466,
											"height": 24
										},
										"visible": true,
										"metadata": {
											"opacity": 1
										},
										"image": {
											"path": "images/Layer-contentNoM-njm1rjvb.png",
											"frame": {
												"x": 447,
												"y": 1028,
												"width": 466,
												"height": 24
											}
										},
										"children": []
									},
									{
										"objectId": "58BF55A2-0493-4B62-9029-BBA83A0FC0A1",
										"kind": "text",
										"name": "contentFillM",
										"originalName": "contentFillM",
										"maskFrame": null,
										"layerFrame": {
											"x": 446,
											"y": 1027,
											"width": 184,
											"height": 21
										},
										"visible": false,
										"metadata": {
											"opacity": 1,
											"string": "First experiment report",
											"css": [
												"/* First experiment rep: */",
												"font-family: HelveticaNeue;",
												"font-size: 18px;",
												"color: #9B9B9B;"
											]
										},
										"image": {
											"path": "images/Layer-contentFillM-nthcrju1.png",
											"frame": {
												"x": 446,
												"y": 1027,
												"width": 184,
												"height": 21
											}
										},
										"children": []
									},
									{
										"objectId": "A296A1D0-52D5-46CA-B99E-3825338323F2",
										"kind": "group",
										"name": "boxArea",
										"originalName": "boxArea",
										"maskFrame": null,
										"layerFrame": {
											"x": 366,
											"y": 850,
											"width": 715,
											"height": 546
										},
										"visible": true,
										"metadata": {
											"opacity": 1
										},
										"image": {
											"path": "images/Layer-boxArea-qti5nkex.png",
											"frame": {
												"x": 366,
												"y": 850,
												"width": 715,
												"height": 546
											}
										},
										"children": []
									},
									{
										"objectId": "E32094EE-6FFB-405E-B37B-086B48628FFA",
										"kind": "group",
										"name": "textEditor",
										"originalName": "textEditor",
										"maskFrame": null,
										"layerFrame": {
											"x": 412,
											"y": 947,
											"width": 624,
											"height": 349
										},
										"visible": true,
										"metadata": {
											"opacity": 1
										},
										"image": {
											"path": "images/Layer-textEditor-rtmymdk0.png",
											"frame": {
												"x": 412,
												"y": 947,
												"width": 624,
												"height": 349
											}
										},
										"children": [
											{
												"objectId": "C399C04C-CA19-4116-89E9-1087331FA246",
												"kind": "group",
												"name": "Paragraph",
												"originalName": "Paragraph",
												"maskFrame": null,
												"layerFrame": {
													"x": 704.5833333333308,
													"y": 977.4826789838335,
													"width": 84,
													"height": 15
												},
												"visible": true,
												"metadata": {
													"opacity": 1
												},
												"children": [
													{
														"objectId": "CA158BD9-C373-4A14-98C6-63CA31DC4C4B",
														"kind": "group",
														"name": "gizmo_list",
														"originalName": "gizmo-list",
														"maskFrame": null,
														"layerFrame": {
															"x": 704.6666666666655,
															"y": 977.4826789838335,
															"width": 19,
															"height": 15
														},
														"visible": true,
														"metadata": {
															"opacity": 1
														},
														"children": [
															{
																"objectId": "FBCAC83D-E7B6-4BC0-9E7D-45163C35CDCD",
																"kind": "group",
																"name": "Group",
																"originalName": "Group",
																"maskFrame": null,
																"layerFrame": {
																	"x": 704.6666666666655,
																	"y": 977.4826789838335,
																	"width": 19,
																	"height": 15
																},
																"visible": true,
																"metadata": {
																	"opacity": 1
																},
																"children": [
																	{
																		"objectId": "B55079C2-6C85-4024-B4C4-17AA4E9F0087",
																		"kind": "group",
																		"name": "Production",
																		"originalName": "Production",
																		"maskFrame": null,
																		"layerFrame": {
																			"x": 704.6666666666619,
																			"y": 977.4826789838335,
																			"width": 19,
																			"height": 15
																		},
																		"visible": true,
																		"metadata": {
																			"opacity": 1
																		},
																		"children": [
																			{
																				"objectId": "7AF1FAA9-C6D1-4AFC-985D-51605196C86A",
																				"kind": "group",
																				"name": "Group1",
																				"originalName": "Group",
																				"maskFrame": null,
																				"layerFrame": {
																					"x": 703.8867187499989,
																					"y": 977.7365401270206,
																					"width": 20,
																					"height": 15
																				},
																				"visible": true,
																				"metadata": {
																					"opacity": 1
																				},
																				"image": {
																					"path": "images/Layer-Group-n0fgmuzb.png",
																					"frame": {
																						"x": 703.8867187499989,
																						"y": 977.7365401270206,
																						"width": 20,
																						"height": 15
																					}
																				},
																				"children": []
																			}
																		]
																	},
																	{
																		"objectId": "3140AF62-81DC-4157-AAB0-04C8CFBC683E",
																		"kind": "group",
																		"name": "_x36_4px_boxes",
																		"originalName": "_x36_4px_boxes",
																		"maskFrame": null,
																		"layerFrame": {
																			"x": 705.6666666666619,
																			"y": 978.4826789838335,
																			"width": 14,
																			"height": 13
																		},
																		"visible": true,
																		"metadata": {
																			"opacity": 1
																		},
																		"image": {
																			"path": "images/Layer-_x36_4px_boxes-mze0mefg.png",
																			"frame": {
																				"x": 705.6666666666619,
																				"y": 978.4826789838335,
																				"width": 14,
																				"height": 13
																			}
																		},
																		"children": []
																	}
																]
															}
														]
													},
													{
														"objectId": "B85C2F07-A20D-4057-BBB7-1A184180B1A8",
														"kind": "group",
														"name": "gizmo_list1",
														"originalName": "gizmo-list",
														"maskFrame": null,
														"layerFrame": {
															"x": 736.6666666666655,
															"y": 977.4826789838335,
															"width": 16,
															"height": 13
														},
														"visible": true,
														"metadata": {
															"opacity": 1
														},
														"children": [
															{
																"objectId": "5683E715-4C11-463F-84DA-691305DDBEFC",
																"kind": "group",
																"name": "Group2",
																"originalName": "Group",
																"maskFrame": null,
																"layerFrame": {
																	"x": 736.5,
																	"y": 977.4826789838335,
																	"width": 16,
																	"height": 13
																},
																"visible": true,
																"metadata": {
																	"opacity": 1
																},
																"children": [
																	{
																		"objectId": "68CA1813-B31F-4BB5-9FE5-41A43A32CABD",
																		"kind": "group",
																		"name": "Production1",
																		"originalName": "Production",
																		"maskFrame": null,
																		"layerFrame": {
																			"x": 736.5,
																			"y": 977.4826789838328,
																			"width": 16,
																			"height": 13
																		},
																		"visible": true,
																		"metadata": {
																			"opacity": 1
																		},
																		"children": [
																			{
																				"objectId": "1DC60430-4669-4BD9-A6BD-7EECF6BE0739",
																				"kind": "group",
																				"name": "Group3",
																				"originalName": "Group",
																				"maskFrame": null,
																				"layerFrame": {
																					"x": 736.921875,
																					"y": 978.122834872979,
																					"width": 16,
																					"height": 12
																				},
																				"visible": true,
																				"metadata": {
																					"opacity": 1
																				},
																				"image": {
																					"path": "images/Layer-Group-murdnja0.png",
																					"frame": {
																						"x": 736.921875,
																						"y": 978.122834872979,
																						"width": 16,
																						"height": 12
																					}
																				},
																				"children": []
																			}
																		]
																	},
																	{
																		"objectId": "C214BE13-26BB-4A20-9E26-CA89BF24A8DD",
																		"kind": "group",
																		"name": "_x36_4px_boxes1",
																		"originalName": "_x36_4px_boxes",
																		"maskFrame": null,
																		"layerFrame": {
																			"x": 735.5,
																			"y": 977.4826789838335,
																			"width": 13,
																			"height": 13
																		},
																		"visible": true,
																		"metadata": {
																			"opacity": 1
																		},
																		"image": {
																			"path": "images/Layer-_x36_4px_boxes-qzixnejf.png",
																			"frame": {
																				"x": 735.5,
																				"y": 977.4826789838335,
																				"width": 13,
																				"height": 13
																			}
																		},
																		"children": []
																	}
																]
															}
														]
													},
													{
														"objectId": "53C3A4C2-6612-4DD2-8A2E-CA7915DFFBEE",
														"kind": "group",
														"name": "gizmo_alignment",
														"originalName": "gizmo-alignment",
														"maskFrame": null,
														"layerFrame": {
															"x": 764.6666666666655,
															"y": 977.4826789838335,
															"width": 13,
															"height": 13
														},
														"visible": true,
														"metadata": {
															"opacity": 1
														},
														"children": [
															{
																"objectId": "84A839F6-3B35-4779-9DBE-EE65FA6A055A",
																"kind": "group",
																"name": "Group4",
																"originalName": "Group",
																"maskFrame": null,
																"layerFrame": {
																	"x": 764.3333333333321,
																	"y": 977.4826789838335,
																	"width": 13,
																	"height": 13
																},
																"visible": true,
																"metadata": {
																	"opacity": 1
																},
																"children": [
																	{
																		"objectId": "606ACCDB-5CBB-4678-A858-A06BC2394A00",
																		"kind": "group",
																		"name": "Production2",
																		"originalName": "Production",
																		"maskFrame": null,
																		"layerFrame": {
																			"x": 764.3333333333321,
																			"y": 977.4826789838328,
																			"width": 13,
																			"height": 13
																		},
																		"visible": true,
																		"metadata": {
																			"opacity": 1
																		},
																		"children": [
																			{
																				"objectId": "501876D1-34F0-490F-AF1D-7EC5B96E1FEF",
																				"kind": "group",
																				"name": "Group5",
																				"originalName": "Group",
																				"maskFrame": null,
																				"layerFrame": {
																					"x": 764.7552083333321,
																					"y": 978.122834872979,
																					"width": 13,
																					"height": 12
																				},
																				"visible": true,
																				"metadata": {
																					"opacity": 1
																				},
																				"image": {
																					"path": "images/Layer-Group-ntaxodc2.png",
																					"frame": {
																						"x": 764.7552083333321,
																						"y": 978.122834872979,
																						"width": 13,
																						"height": 12
																					}
																				},
																				"children": []
																			}
																		]
																	},
																	{
																		"objectId": "B785AB17-47F8-4736-8CD5-1B7B9174AFF1",
																		"kind": "group",
																		"name": "_x36_4px_boxes2",
																		"originalName": "_x36_4px_boxes",
																		"maskFrame": null,
																		"layerFrame": {
																			"x": 763.3333333333321,
																			"y": 977.4826789838335,
																			"width": 14,
																			"height": 13
																		},
																		"visible": true,
																		"metadata": {
																			"opacity": 1
																		},
																		"image": {
																			"path": "images/Layer-_x36_4px_boxes-qjc4nufc.png",
																			"frame": {
																				"x": 763.3333333333321,
																				"y": 977.4826789838335,
																				"width": 14,
																				"height": 13
																			}
																		},
																		"children": []
																	}
																]
															}
														]
													},
													{
														"objectId": "0D150F53-E8DD-439C-BD0A-C1C4CB9869C6",
														"kind": "group",
														"name": "gizmo_navigate_down",
														"originalName": "gizmo-navigate-down",
														"maskFrame": null,
														"layerFrame": {
															"x": 779.6666666666655,
															"y": 977.4826789838335,
															"width": 9,
															"height": 6
														},
														"visible": true,
														"metadata": {
															"opacity": 1
														},
														"image": {
															"path": "images/Layer-gizmo_navigate_down-meqxntbg.png",
															"frame": {
																"x": 779.6666666666655,
																"y": 977.4826789838335,
																"width": 9,
																"height": 6
															}
														},
														"children": []
													}
												]
											},
											{
												"objectId": "47AA4312-C8E7-46FE-81F6-106183F744C4",
												"kind": "group",
												"name": "Font_style",
												"originalName": "Font style",
												"maskFrame": null,
												"layerFrame": {
													"x": 602.5833333333321,
													"y": 973.4826789838335,
													"width": 74,
													"height": 17
												},
												"visible": true,
												"metadata": {
													"opacity": 1
												},
												"image": {
													"path": "images/Layer-Font_style-nddbqtqz.png",
													"frame": {
														"x": 602.5833333333321,
														"y": 973.4826789838335,
														"width": 74,
														"height": 17
													}
												},
												"children": [
													{
														"objectId": "0C4B70F9-33BB-44AC-A3A5-35BEFE7C7F08",
														"kind": "group",
														"name": "gizmo_pencel",
														"originalName": "gizmo-pencel",
														"maskFrame": null,
														"layerFrame": {
															"x": 659.5833333333312,
															"y": 973.4826789838335,
															"width": 17,
															"height": 17
														},
														"visible": true,
														"metadata": {
															"opacity": 1
														},
														"image": {
															"path": "images/Layer-gizmo_pencel-mem0qjcw.png",
															"frame": {
																"x": 659.5833333333312,
																"y": 973.4826789838335,
																"width": 17,
																"height": 17
															}
														},
														"children": []
													}
												]
											},
											{
												"objectId": "A1F7B80B-D663-4524-AAA3-51BD5B7857AD",
												"kind": "group",
												"name": "Font",
												"originalName": "Font",
												"maskFrame": null,
												"layerFrame": {
													"x": 451.58333333333337,
													"y": 979.482678983834,
													"width": 118,
													"height": 12
												},
												"visible": true,
												"metadata": {
													"opacity": 1
												},
												"image": {
													"path": "images/Layer-Font-qtfgn0i4.png",
													"frame": {
														"x": 451.58333333333337,
														"y": 979.482678983834,
														"width": 118,
														"height": 12
													}
												},
												"children": [
													{
														"objectId": "99FE357A-AA51-4073-9D89-C4EF2E44E941",
														"kind": "group",
														"name": "gizmo_navigate_down1",
														"originalName": "gizmo-navigate-down",
														"maskFrame": null,
														"layerFrame": {
															"x": 555.4999999999987,
															"y": 980.3972286374137,
															"width": 14,
															"height": 9
														},
														"visible": true,
														"metadata": {
															"opacity": 1
														},
														"image": {
															"path": "images/Layer-gizmo_navigate_down-otlgrtm1.png",
															"frame": {
																"x": 555.4999999999987,
																"y": 980.3972286374137,
																"width": 14,
																"height": 9
															}
														},
														"children": []
													},
													{
														"objectId": "A0288B06-BAC7-4EE1-A972-D7BEA9F576DF",
														"kind": "group",
														"name": "gizmo_navigate_down2",
														"originalName": "gizmo-navigate-down",
														"maskFrame": null,
														"layerFrame": {
															"x": 512.5,
															"y": 980.3972286374131,
															"width": 13,
															"height": 9
														},
														"visible": true,
														"metadata": {
															"opacity": 1
														},
														"image": {
															"path": "images/Layer-gizmo_navigate_down-qtayodhc.png",
															"frame": {
																"x": 512.5,
																"y": 980.3972286374131,
																"width": 13,
																"height": 9
															}
														},
														"children": []
													}
												]
											}
										]
									}
								]
							},
							{
								"objectId": "874CE0C7-EA5D-4D1B-9546-381A01821CB7",
								"kind": "group",
								"name": "neckM",
								"originalName": "neckM*",
								"maskFrame": null,
								"layerFrame": {
									"x": 715,
									"y": 771,
									"width": 15,
									"height": 65
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-neckM-odc0q0uw.png",
									"frame": {
										"x": 715,
										"y": 771,
										"width": 15,
										"height": 65
									}
								},
								"children": []
							}
						]
					},
					{
						"objectId": "64E10515-ED80-4360-BCB5-76514F0E939F",
						"kind": "text",
						"name": "resLine6",
						"originalName": "resLine6",
						"maskFrame": null,
						"layerFrame": {
							"x": 589,
							"y": 357,
							"width": 116,
							"height": 15
						},
						"visible": true,
						"metadata": {
							"opacity": 1,
							"string": "Research Line",
							"css": [
								"/* Research Line: */",
								"opacity: 0.5;",
								"font-family: .HelveticaNeueDeskInterface-Regular;",
								"font-size: 18px;",
								"color: #000000;",
								"letter-spacing: 0;"
							]
						},
						"image": {
							"path": "images/Layer-resLine6-njrfmta1.png",
							"frame": {
								"x": 589,
								"y": 357,
								"width": 116,
								"height": 15
							}
						},
						"children": []
					},
					{
						"objectId": "EA1996F6-496D-4D28-AB5A-202AFE86BBDC",
						"kind": "text",
						"name": "overview6",
						"originalName": "overview6",
						"maskFrame": null,
						"layerFrame": {
							"x": 230,
							"y": 356,
							"width": 76,
							"height": 16
						},
						"visible": true,
						"metadata": {
							"opacity": 1,
							"string": "Overview",
							"css": [
								"/* Overview: */",
								"opacity: 0.5;",
								"font-family: .HelveticaNeueDeskInterface-Regular;",
								"font-size: 18px;",
								"color: #000000;",
								"letter-spacing: 0;"
							]
						},
						"image": {
							"path": "images/Layer-overview6-ruexotk2.png",
							"frame": {
								"x": 230,
								"y": 356,
								"width": 76,
								"height": 16
							}
						},
						"children": []
					},
					{
						"objectId": "C8D22EFD-0932-4381-9503-7D9A2EA4AB79",
						"kind": "group",
						"name": "header6",
						"originalName": "header6*",
						"maskFrame": null,
						"layerFrame": {
							"x": -1,
							"y": -2,
							"width": 1442,
							"height": 407
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-header6-qzhemjjf.jpg",
							"frame": {
								"x": -1,
								"y": -2,
								"width": 1442,
								"height": 407
							}
						},
						"children": []
					},
					{
						"objectId": "F1E8FAB5-73D0-4AB3-B79A-659B0DE14BCA",
						"kind": "group",
						"name": "btn_resAdd_addM_active",
						"originalName": "btn_resAdd_addM_active",
						"maskFrame": null,
						"layerFrame": {
							"x": 685,
							"y": 700.0000000000001,
							"width": 72,
							"height": 72
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-btn_resAdd_addM_active-rjffoezb.png",
							"frame": {
								"x": 685,
								"y": 700.0000000000001,
								"width": 72,
								"height": 72
							}
						},
						"children": []
					},
					{
						"objectId": "B97B88E2-1006-4689-B23A-A959CC72644C",
						"kind": "group",
						"name": "btn_resAdd_addM",
						"originalName": "btn_resAdd_addM",
						"maskFrame": null,
						"layerFrame": {
							"x": 685,
							"y": 700,
							"width": 73,
							"height": 73
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-btn_resAdd_addM-qjk3qjg4.png",
							"frame": {
								"x": 685,
								"y": 700,
								"width": 73,
								"height": 73
							}
						},
						"children": []
					},
					{
						"objectId": "3F5CBEA6-2527-4446-8EB5-305DCD174827",
						"kind": "group",
						"name": "bg_back",
						"originalName": "bg_back",
						"maskFrame": null,
						"layerFrame": {
							"x": 224,
							"y": 736,
							"width": 992,
							"height": 900
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-bg_back-m0y1q0jf.png",
							"frame": {
								"x": 224,
								"y": 736,
								"width": 992,
								"height": 900
							}
						},
						"children": []
					},
					{
						"objectId": "EDF026E9-EE7D-4318-994C-9454F2AFC9C0",
						"kind": "group",
						"name": "topM",
						"originalName": "topM",
						"maskFrame": null,
						"layerFrame": {
							"x": 224,
							"y": 474,
							"width": 995,
							"height": 375
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-topM-rurgmdi2.png",
							"frame": {
								"x": 224,
								"y": 474,
								"width": 995,
								"height": 375
							}
						},
						"children": [
							{
								"objectId": "BC6EDE12-AB28-4CB0-9DF6-EC20C9569F3D",
								"kind": "group",
								"name": "Group6",
								"originalName": "Group",
								"maskFrame": null,
								"layerFrame": {
									"x": 804,
									"y": 559,
									"width": 175,
									"height": 136
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-Group-qkm2rurf.png",
									"frame": {
										"x": 804,
										"y": 559,
										"width": 175,
										"height": 136
									}
								},
								"children": []
							},
							{
								"objectId": "79CB015C-D0F9-4614-8FA8-446C141845AB",
								"kind": "group",
								"name": "Group7",
								"originalName": "Group",
								"maskFrame": null,
								"layerFrame": {
									"x": 463,
									"y": 559,
									"width": 174,
									"height": 136
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-Group-nzldqjax.png",
									"frame": {
										"x": 463,
										"y": 559,
										"width": 174,
										"height": 136
									}
								},
								"children": []
							}
						]
					},
					{
						"objectId": "D6B12988-5B73-46D7-8C69-1AE0BFB50B72",
						"kind": "group",
						"name": "bg",
						"originalName": "bg*",
						"maskFrame": null,
						"layerFrame": {
							"x": 2,
							"y": 1086,
							"width": 1440,
							"height": 660
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-bg-rdzcmti5.png",
							"frame": {
								"x": 2,
								"y": 1086,
								"width": 1440,
								"height": 660
							}
						},
						"children": []
					}
				]
			}
		]
	},
	{
		"objectId": "2621AC87-BFC9-4B86-B14E-6727744F4596",
		"kind": "artboard",
		"name": "currentRes",
		"originalName": "currentRes",
		"maskFrame": null,
		"layerFrame": {
			"x": 14328,
			"y": 11825,
			"width": 1440,
			"height": 1052
		},
		"visible": true,
		"metadata": {},
		"backgroundColor": "rgba(245, 245, 245, 1)",
		"children": [
			{
				"objectId": "6E82B6D8-7E08-48D6-9F34-DEE657194CD0",
				"kind": "group",
				"name": "content2",
				"originalName": "content2",
				"maskFrame": null,
				"layerFrame": {
					"x": -1,
					"y": -2,
					"width": 1442,
					"height": 1065
				},
				"visible": true,
				"metadata": {
					"opacity": 1
				},
				"children": [
					{
						"objectId": "BB07D5A3-259F-472B-876A-9F82BFD1C66D",
						"kind": "group",
						"name": "header2",
						"originalName": "header2*",
						"maskFrame": null,
						"layerFrame": {
							"x": -1,
							"y": -2,
							"width": 1442,
							"height": 326
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-header2-qkiwn0q1.jpg",
							"frame": {
								"x": -1,
								"y": -2,
								"width": 1442,
								"height": 326
							}
						},
						"children": []
					},
					{
						"objectId": "CA333D74-6CB5-458B-8833-D762734E9E14",
						"kind": "text",
						"name": "resLine2",
						"originalName": "resLine2*",
						"maskFrame": null,
						"layerFrame": {
							"x": 589,
							"y": 357,
							"width": 116,
							"height": 15
						},
						"visible": true,
						"metadata": {
							"opacity": 1,
							"string": "Research Line",
							"css": [
								"/* Research Line: */",
								"opacity: 0.5;",
								"font-family: .HelveticaNeueDeskInterface-Regular;",
								"font-size: 18px;",
								"color: #000000;",
								"letter-spacing: 0;"
							]
						},
						"image": {
							"path": "images/Layer-resLine2-q0ezmzne.png",
							"frame": {
								"x": 589,
								"y": 357,
								"width": 116,
								"height": 15
							}
						},
						"children": []
					},
					{
						"objectId": "D5DF31E6-37DF-42F9-9559-5A176D04B743",
						"kind": "text",
						"name": "overview2",
						"originalName": "overview2*",
						"maskFrame": null,
						"layerFrame": {
							"x": 230,
							"y": 356,
							"width": 76,
							"height": 16
						},
						"visible": true,
						"metadata": {
							"opacity": 1,
							"string": "Overview",
							"css": [
								"/* Overview: */",
								"opacity: 0.5;",
								"font-family: .HelveticaNeueDeskInterface-Regular;",
								"font-size: 18px;",
								"color: #000000;",
								"letter-spacing: 0;"
							]
						},
						"image": {
							"path": "images/Layer-overview2-rdverjmx.png",
							"frame": {
								"x": 230,
								"y": 356,
								"width": 76,
								"height": 16
							}
						},
						"children": []
					},
					{
						"objectId": "0C496823-D523-4566-A6D6-A3689F6C9EA6",
						"kind": "group",
						"name": "Indicater",
						"originalName": "Indicater*",
						"maskFrame": null,
						"layerFrame": {
							"x": 1076,
							"y": 475,
							"width": 90,
							"height": 17
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-Indicater-mem0oty4.png",
							"frame": {
								"x": 1076,
								"y": 475,
								"width": 90,
								"height": 17
							}
						},
						"children": []
					},
					{
						"objectId": "BE46BC3E-BCE6-4FA7-B15B-42D5F8EE9C98",
						"kind": "group",
						"name": "btn_add_currentRes",
						"originalName": "btn_add_currentRes*",
						"maskFrame": null,
						"layerFrame": {
							"x": 638,
							"y": 658,
							"width": 34,
							"height": 34
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-btn_add_currentRes-qku0nkjd.png",
							"frame": {
								"x": 638,
								"y": 658,
								"width": 34,
								"height": 34
							}
						},
						"children": []
					},
					{
						"objectId": "5C5B1807-8503-4D5D-949B-2B4DFCAE66ED",
						"kind": "text",
						"name": "resProDate",
						"originalName": "resProDate",
						"maskFrame": null,
						"layerFrame": {
							"x": 348,
							"y": 795,
							"width": 107,
							"height": 14
						},
						"visible": true,
						"metadata": {
							"opacity": 1,
							"string": "September, 2017\n\n",
							"css": [
								"/* September, 2017: */",
								"font-family: HelveticaNeue;",
								"font-size: 14px;",
								"color: #9B9B9B;"
							]
						},
						"image": {
							"path": "images/Layer-resProDate-num1qje4.png",
							"frame": {
								"x": 348,
								"y": 795,
								"width": 107,
								"height": 14
							}
						},
						"children": []
					},
					{
						"objectId": "EA25631F-9BF8-4694-B692-03E04AC823F0",
						"kind": "group",
						"name": "resPro",
						"originalName": "resPro",
						"maskFrame": null,
						"layerFrame": {
							"x": 306,
							"y": 564,
							"width": 211,
							"height": 221
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"children": [
							{
								"objectId": "8C54AF22-9F6A-43FF-B801-083868E5A3A0",
								"kind": "group",
								"name": "research",
								"originalName": "research",
								"maskFrame": null,
								"layerFrame": {
									"x": 306,
									"y": 564,
									"width": 211,
									"height": 221
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-research-oem1nefg.png",
									"frame": {
										"x": 306,
										"y": 564,
										"width": 211,
										"height": 221
									}
								},
								"children": []
							}
						]
					},
					{
						"objectId": "94973495-7E83-4211-8386-858267FADBF5",
						"kind": "group",
						"name": "tabBar2",
						"originalName": "tabBar2*",
						"maskFrame": null,
						"layerFrame": {
							"x": 0,
							"y": 324,
							"width": 1440,
							"height": 739
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-tabBar2-otq5nzm0.png",
							"frame": {
								"x": 0,
								"y": 324,
								"width": 1440,
								"height": 739
							}
						},
						"children": []
					}
				]
			}
		]
	},
	{
		"objectId": "4CA7C2C6-88F7-43E2-A5DF-CD3F65FA705F",
		"kind": "artboard",
		"name": "newResLine",
		"originalName": "newResLine",
		"maskFrame": null,
		"layerFrame": {
			"x": 15885,
			"y": 11825,
			"width": 1440,
			"height": 1466
		},
		"visible": true,
		"metadata": {},
		"backgroundColor": "rgba(245, 245, 245, 1)",
		"children": [
			{
				"objectId": "5D783F96-D5DA-4EE8-86A4-337F54815E95",
				"kind": "group",
				"name": "contentNewRes",
				"originalName": "contentNewRes",
				"maskFrame": null,
				"layerFrame": {
					"x": -1,
					"y": -2,
					"width": 1443,
					"height": 1460
				},
				"visible": true,
				"metadata": {
					"opacity": 1
				},
				"children": [
					{
						"objectId": "50A64A01-1418-4458-B026-D7EDE11370DF",
						"kind": "text",
						"name": "btn_2017",
						"originalName": "btn_2017",
						"maskFrame": null,
						"layerFrame": {
							"x": 699,
							"y": 509,
							"width": 44,
							"height": 16
						},
						"visible": true,
						"metadata": {
							"opacity": 1,
							"string": "2017",
							"css": [
								"/* 2017: */",
								"font-family: .HelveticaNeueDeskInterface-Regular;",
								"font-size: 20px;",
								"color: #C6C6C6;"
							]
						},
						"image": {
							"path": "images/Layer-btn_2017-ntbbnjrb.png",
							"frame": {
								"x": 699,
								"y": 509,
								"width": 44,
								"height": 16
							}
						},
						"children": []
					},
					{
						"objectId": "CC8145A4-82D9-459B-A242-C3856845E08E",
						"kind": "group",
						"name": "btn_resAdd_click_active",
						"originalName": "btn_resAdd_click_active",
						"maskFrame": null,
						"layerFrame": {
							"x": 623,
							"y": 837,
							"width": 199,
							"height": 52
						},
						"visible": false,
						"metadata": {
							"opacity": 1
						},
						"children": [
							{
								"objectId": "F8DCF0B4-CC70-45F6-B4AC-EF5068536F72",
								"kind": "group",
								"name": "future_active",
								"originalName": "future_active",
								"maskFrame": null,
								"layerFrame": {
									"x": 770,
									"y": 837,
									"width": 52,
									"height": 52
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-future_active-rjheq0yw.png",
									"frame": {
										"x": 770,
										"y": 837,
										"width": 52,
										"height": 52
									}
								},
								"children": [
									{
										"objectId": "182AEF5C-DE81-48D8-B831-2A8EBECB448F",
										"kind": "group",
										"name": "deadlineIcon",
										"originalName": "deadlineIcon",
										"maskFrame": null,
										"layerFrame": {
											"x": 782,
											"y": 849,
											"width": 28,
											"height": 28
										},
										"visible": true,
										"metadata": {
											"opacity": 1
										},
										"children": [
											{
												"objectId": "0EBD0731-7696-49ED-BEE5-CAEC9B663FF9",
												"kind": "group",
												"name": "gizmo_alarm_clock",
												"originalName": "gizmo-alarm-clock",
												"maskFrame": null,
												"layerFrame": {
													"x": 782.25,
													"y": 849.25,
													"width": 28,
													"height": 27
												},
												"visible": true,
												"metadata": {
													"opacity": 1
												},
												"image": {
													"path": "images/Layer-gizmo_alarm_clock-mevcrda3.png",
													"frame": {
														"x": 782.25,
														"y": 849.25,
														"width": 28,
														"height": 27
													}
												},
												"children": []
											}
										]
									}
								]
							},
							{
								"objectId": "3D19F8BB-C162-49F3-9C08-2CC9FA5BCC84",
								"kind": "group",
								"name": "history_active",
								"originalName": "history_active",
								"maskFrame": null,
								"layerFrame": {
									"x": 623,
									"y": 837,
									"width": 52,
									"height": 52
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-history_active-m0qxouy4.png",
									"frame": {
										"x": 623,
										"y": 837,
										"width": 52,
										"height": 52
									}
								},
								"children": [
									{
										"objectId": "649F5154-3AD9-4ABE-9614-896D5E0F83CD",
										"kind": "group",
										"name": "gizmo_flag",
										"originalName": "gizmo-flag",
										"maskFrame": null,
										"layerFrame": {
											"x": 636.9999999999982,
											"y": 850,
											"width": 25,
											"height": 25
										},
										"visible": true,
										"metadata": {
											"opacity": 1
										},
										"image": {
											"path": "images/Layer-gizmo_flag-njq5rjux.png",
											"frame": {
												"x": 636.9999999999982,
												"y": 850,
												"width": 25,
												"height": 25
											}
										},
										"children": []
									}
								]
							}
						]
					},
					{
						"objectId": "D77093B6-1814-4739-96F7-E0C24C0C4F08",
						"kind": "group",
						"name": "btn_resAdd_click",
						"originalName": "btn_resAdd_click",
						"maskFrame": null,
						"layerFrame": {
							"x": 602,
							"y": 767,
							"width": 228,
							"height": 143
						},
						"visible": false,
						"metadata": {
							"opacity": 1
						},
						"children": [
							{
								"objectId": "96710118-6485-4126-9190-1CB41D51C8B3",
								"kind": "text",
								"name": "meetingRemi",
								"originalName": "meetingRemi",
								"maskFrame": null,
								"layerFrame": {
									"x": 603,
									"y": 896,
									"width": 91,
									"height": 14
								},
								"visible": true,
								"metadata": {
									"opacity": 1,
									"string": "History Record",
									"css": [
										"/* History Record: */",
										"font-family: MicrosoftSansSerif;",
										"font-size: 14px;",
										"color: #858585;"
									]
								},
								"image": {
									"path": "images/Layer-meetingRemi-oty3mtax.png",
									"frame": {
										"x": 603,
										"y": 896,
										"width": 91,
										"height": 14
									}
								},
								"children": []
							},
							{
								"objectId": "68EFF4DF-E11F-44AC-8416-FE8D3EC134A5",
								"kind": "text",
								"name": "milestoneRemi",
								"originalName": "milestoneRemi",
								"maskFrame": null,
								"layerFrame": {
									"x": 768,
									"y": 896,
									"width": 62,
									"height": 12
								},
								"visible": true,
								"metadata": {
									"opacity": 1,
									"string": "New Task",
									"css": [
										"/* New Task: */",
										"font-family: MicrosoftSansSerif;",
										"font-size: 14px;",
										"color: #858585;"
									]
								},
								"image": {
									"path": "images/Layer-milestoneRemi-njhfrky0.png",
									"frame": {
										"x": 768,
										"y": 896,
										"width": 62,
										"height": 12
									}
								},
								"children": []
							},
							{
								"objectId": "31524000-1798-4D21-B2CF-E887C32F5365",
								"kind": "group",
								"name": "btn_future",
								"originalName": "btn_future",
								"maskFrame": null,
								"layerFrame": {
									"x": 770,
									"y": 837,
									"width": 52,
									"height": 52
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-btn_future-mze1mjqw.png",
									"frame": {
										"x": 770,
										"y": 837,
										"width": 52,
										"height": 52
									}
								},
								"children": [
									{
										"objectId": "8C10DF37-40E6-4328-9BC7-1AF0AD32FA1C",
										"kind": "group",
										"name": "deadlineIcon1",
										"originalName": "deadlineIcon",
										"maskFrame": null,
										"layerFrame": {
											"x": 782,
											"y": 849,
											"width": 28,
											"height": 28
										},
										"visible": true,
										"metadata": {
											"opacity": 1
										},
										"children": [
											{
												"objectId": "0AC4B8EF-964F-4FD6-BD7A-26FC6153D264",
												"kind": "group",
												"name": "gizmo_alarm_clock1",
												"originalName": "gizmo-alarm-clock",
												"maskFrame": null,
												"layerFrame": {
													"x": 782.25,
													"y": 849.25,
													"width": 28,
													"height": 27
												},
												"visible": true,
												"metadata": {
													"opacity": 1
												},
												"image": {
													"path": "images/Layer-gizmo_alarm_clock-mefdnei4.png",
													"frame": {
														"x": 782.25,
														"y": 849.25,
														"width": 28,
														"height": 27
													}
												},
												"children": []
											}
										]
									}
								]
							},
							{
								"objectId": "0717B7CB-EE06-4454-A7FD-A8F02A56303D",
								"kind": "group",
								"name": "btn_history",
								"originalName": "btn_history",
								"maskFrame": null,
								"layerFrame": {
									"x": 623,
									"y": 837,
									"width": 52,
									"height": 52
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-btn_history-mdcxn0i3.png",
									"frame": {
										"x": 623,
										"y": 837,
										"width": 52,
										"height": 52
									}
								},
								"children": [
									{
										"objectId": "0E7B0557-C7E2-4975-ACB2-680BD2EFBD04",
										"kind": "group",
										"name": "gizmo_flag1",
										"originalName": "gizmo-flag",
										"maskFrame": null,
										"layerFrame": {
											"x": 636.9999999999982,
											"y": 850,
											"width": 25,
											"height": 25
										},
										"visible": true,
										"metadata": {
											"opacity": 1
										},
										"image": {
											"path": "images/Layer-gizmo_flag-meu3qja1.png",
											"frame": {
												"x": 636.9999999999982,
												"y": 850,
												"width": 25,
												"height": 25
											}
										},
										"children": []
									}
								]
							},
							{
								"objectId": "8A2DEF38-3E38-4E94-816A-CAAC08937F65",
								"kind": "group",
								"name": "newLine",
								"originalName": "newLine",
								"maskFrame": null,
								"layerFrame": {
									"x": 648,
									"y": 768,
									"width": 149,
									"height": 71
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-newLine-oeeyrevg.png",
									"frame": {
										"x": 648,
										"y": 768,
										"width": 149,
										"height": 71
									}
								},
								"children": []
							}
						]
					},
					{
						"objectId": "A5A0250F-14FB-4C0A-B33F-DD77753B03F9",
						"kind": "group",
						"name": "btn_resAdd_active",
						"originalName": "btn_resAdd_active",
						"maskFrame": null,
						"layerFrame": {
							"x": 683,
							"y": 695,
							"width": 75,
							"height": 73
						},
						"visible": false,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-btn_resAdd_active-qtvbmdi1.png",
							"frame": {
								"x": 683,
								"y": 695,
								"width": 75,
								"height": 73
							}
						},
						"children": []
					},
					{
						"objectId": "ED34574A-4500-4BCE-823D-CE313D651CB6",
						"kind": "group",
						"name": "btn_resAdd",
						"originalName": "btn_resAdd",
						"maskFrame": null,
						"layerFrame": {
							"x": 686,
							"y": 695,
							"width": 73,
							"height": 74
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-btn_resAdd-ruqzndu3.png",
							"frame": {
								"x": 686,
								"y": 695,
								"width": 73,
								"height": 74
							}
						},
						"children": []
					},
					{
						"objectId": "92B604B2-301D-40C2-A585-610D344F9ABA",
						"kind": "text",
						"name": "resLine5",
						"originalName": "resLine5",
						"maskFrame": null,
						"layerFrame": {
							"x": 589,
							"y": 358,
							"width": 116,
							"height": 15
						},
						"visible": true,
						"metadata": {
							"opacity": 1,
							"string": "Research Line",
							"css": [
								"/* Research Line: */",
								"opacity: 0.5;",
								"font-family: .HelveticaNeueDeskInterface-Regular;",
								"font-size: 18px;",
								"color: #000000;",
								"letter-spacing: 0;"
							]
						},
						"image": {
							"path": "images/Layer-resLine5-otjcnja0.png",
							"frame": {
								"x": 589,
								"y": 358,
								"width": 116,
								"height": 15
							}
						},
						"children": []
					},
					{
						"objectId": "2738CC1C-C83C-4FA0-9396-07755F0DA394",
						"kind": "group",
						"name": "line2",
						"originalName": "line2",
						"maskFrame": null,
						"layerFrame": {
							"x": 564,
							"y": 754,
							"width": 458,
							"height": 413
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"children": [
							{
								"objectId": "37999D8C-0CD6-4E18-863D-3AB190EB454F",
								"kind": "group",
								"name": "deadlineAfter",
								"originalName": "deadlineAfter",
								"maskFrame": null,
								"layerFrame": {
									"x": 625,
									"y": 939,
									"width": 398,
									"height": 94
								},
								"visible": false,
								"metadata": {
									"opacity": 1
								},
								"children": [
									{
										"objectId": "E7C32350-01D7-4762-8B38-E289ED8B5FB1",
										"kind": "group",
										"name": "firstDiscussion",
										"originalName": "firstDiscussion",
										"maskFrame": null,
										"layerFrame": {
											"x": 625,
											"y": 939,
											"width": 398,
											"height": 94
										},
										"visible": true,
										"metadata": {
											"opacity": 1
										},
										"children": [
											{
												"objectId": "B52923A7-C9EF-4A3B-B9B1-9F4BB436DA96",
												"kind": "group",
												"name": "Group_3",
												"originalName": "Group 3",
												"maskFrame": null,
												"layerFrame": {
													"x": 625,
													"y": 939,
													"width": 398,
													"height": 94
												},
												"visible": true,
												"metadata": {
													"opacity": 1
												},
												"image": {
													"path": "images/Layer-Group_3-qjuyotiz.png",
													"frame": {
														"x": 625,
														"y": 939,
														"width": 398,
														"height": 94
													}
												},
												"children": []
											}
										]
									}
								]
							},
							{
								"objectId": "E1058B78-9179-48A9-AE81-789FE78C99FD",
								"kind": "group",
								"name": "deadlineBefore",
								"originalName": "deadlineBefore",
								"maskFrame": null,
								"layerFrame": {
									"x": 564,
									"y": 937,
									"width": 383,
									"height": 57
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"children": [
									{
										"objectId": "E98589E6-60A1-4B11-91E0-5890B3B9708A",
										"kind": "text",
										"name": "deadDate",
										"originalName": "deadDate",
										"maskFrame": null,
										"layerFrame": {
											"x": 564,
											"y": 939,
											"width": 134,
											"height": 16
										},
										"visible": true,
										"metadata": {
											"opacity": 1,
											"string": "22nd, December",
											"css": [
												"/* 22nd, December: */",
												"font-family: HelveticaNeue;",
												"font-size: 18px;",
												"color: #FF6A5A;"
											]
										},
										"image": {
											"path": "images/Layer-deadDate-rtk4ntg5.png",
											"frame": {
												"x": 564,
												"y": 939,
												"width": 134,
												"height": 16
											}
										},
										"children": []
									},
									{
										"objectId": "F421067D-080A-455C-B616-2F80AF42F943",
										"kind": "group",
										"name": "deadPN",
										"originalName": "deadPN",
										"maskFrame": null,
										"layerFrame": {
											"x": 712,
											"y": 937,
											"width": 20,
											"height": 20
										},
										"visible": true,
										"metadata": {
											"opacity": 1
										},
										"image": {
											"path": "images/Layer-deadPN-rjqymta2.png",
											"frame": {
												"x": 712,
												"y": 937,
												"width": 20,
												"height": 20
											}
										},
										"children": []
									},
									{
										"objectId": "BC2881D8-210D-4B3F-92D8-7CBEFBAC3CCA",
										"kind": "group",
										"name": "deadPF",
										"originalName": "deadPF",
										"maskFrame": null,
										"layerFrame": {
											"x": 712,
											"y": 937,
											"width": 20,
											"height": 20
										},
										"visible": false,
										"metadata": {
											"opacity": 1
										},
										"image": {
											"path": "images/Layer-deadPF-qkmyodgx.png",
											"frame": {
												"x": 712,
												"y": 937,
												"width": 20,
												"height": 20
											}
										},
										"children": []
									},
									{
										"objectId": "E31007C3-0C8F-49CB-A12F-BE156F406B6A",
										"kind": "group",
										"name": "deadBox",
										"originalName": "deadBox",
										"maskFrame": null,
										"layerFrame": {
											"x": 753,
											"y": 947,
											"width": 194,
											"height": 47
										},
										"visible": true,
										"metadata": {
											"opacity": 1
										},
										"children": [
											{
												"objectId": "F7CDFD6F-E329-4AD1-8A49-267B88C3C447",
												"kind": "group",
												"name": "deadBCheckF",
												"originalName": "deadBCheckF",
												"maskFrame": null,
												"layerFrame": {
													"x": 771,
													"y": 963,
													"width": 16,
													"height": 16
												},
												"visible": false,
												"metadata": {
													"opacity": 1
												},
												"image": {
													"path": "images/Layer-deadBCheckF-rjddreze.png",
													"frame": {
														"x": 771,
														"y": 963,
														"width": 16,
														"height": 16
													}
												},
												"children": []
											},
											{
												"objectId": "4B192CB6-563B-4D58-BEF7-262D56352594",
												"kind": "group",
												"name": "deadBCheck",
												"originalName": "deadBCheck",
												"maskFrame": null,
												"layerFrame": {
													"x": 771,
													"y": 963,
													"width": 16,
													"height": 16
												},
												"visible": true,
												"metadata": {
													"opacity": 1
												},
												"image": {
													"path": "images/Layer-deadBCheck-neixotjd.png",
													"frame": {
														"x": 771,
														"y": 963,
														"width": 16,
														"height": 16
													}
												},
												"children": []
											},
											{
												"objectId": "E8AB381B-CEDB-4472-BE78-A172C0CFD613",
												"kind": "group",
												"name": "deadBoxOther",
												"originalName": "deadBoxOther",
												"maskFrame": null,
												"layerFrame": {
													"x": 753,
													"y": 947,
													"width": 194,
													"height": 47
												},
												"visible": true,
												"metadata": {
													"opacity": 1
												},
												"image": {
													"path": "images/Layer-deadBoxOther-rthbqjm4.png",
													"frame": {
														"x": 753,
														"y": 947,
														"width": 194,
														"height": 47
													}
												},
												"children": []
											}
										]
									}
								]
							},
							{
								"objectId": "63366A88-DA7D-42C6-B2A1-1B6AA3F3E850",
								"kind": "group",
								"name": "resultBoxOpen",
								"originalName": "resultBoxOpen",
								"maskFrame": null,
								"layerFrame": {
									"x": 754,
									"y": 811,
									"width": 541,
									"height": 560
								},
								"visible": false,
								"metadata": {
									"opacity": 1
								},
								"children": [
									{
										"objectId": "8EC212F0-3440-451A-BA8B-80730A5F4FE7",
										"kind": "group",
										"name": "closeM1Edit",
										"originalName": "closeM1Edit",
										"maskFrame": null,
										"layerFrame": {
											"x": 1240,
											"y": 845,
											"width": 26,
											"height": 16
										},
										"visible": true,
										"metadata": {
											"opacity": 1
										},
										"image": {
											"path": "images/Layer-closeM1Edit-oevdmjey.png",
											"frame": {
												"x": 1240,
												"y": 845,
												"width": 26,
												"height": 16
											}
										},
										"children": []
									},
									{
										"objectId": "DF52BDB3-4437-4CCD-90C7-676006606B38",
										"kind": "group",
										"name": "boxS",
										"originalName": "boxS",
										"maskFrame": null,
										"layerFrame": {
											"x": 754,
											"y": 811,
											"width": 541,
											"height": 444
										},
										"visible": true,
										"metadata": {
											"opacity": 1
										},
										"children": [
											{
												"objectId": "DE08FEE4-5ACA-40EB-A7D5-2F063C73DECC",
												"kind": "group",
												"name": "fileRight",
												"originalName": "fileRight",
												"maskFrame": null,
												"layerFrame": {
													"x": 865,
													"y": 1098,
													"width": 320,
													"height": 273
												},
												"visible": true,
												"metadata": {
													"opacity": 1
												},
												"children": [
													{
														"objectId": "9CE70DCE-DDD2-495D-8A10-5C771D3A5EC9",
														"kind": "group",
														"name": "googleAdded",
														"originalName": "googleAdded",
														"maskFrame": null,
														"layerFrame": {
															"x": 907,
															"y": 1183,
															"width": 149,
															"height": 26
														},
														"visible": false,
														"metadata": {
															"opacity": 1
														},
														"image": {
															"path": "images/Layer-googleAdded-ounfnzbe.png",
															"frame": {
																"x": 907,
																"y": 1183,
																"width": 149,
																"height": 26
															}
														},
														"children": [
															{
																"objectId": "936725E9-ADF2-49D4-AA8E-C8FA5DBB5522",
																"kind": "group",
																"name": "gizmo_check",
																"originalName": "gizmo-check",
																"maskFrame": null,
																"layerFrame": {
																	"x": 907,
																	"y": 1191,
																	"width": 15,
																	"height": 15
																},
																"visible": true,
																"metadata": {
																	"opacity": 1
																},
																"image": {
																	"path": "images/Layer-gizmo_check-otm2nzi1.png",
																	"frame": {
																		"x": 907,
																		"y": 1191,
																		"width": 15,
																		"height": 15
																	}
																},
																"children": []
															}
														]
													},
													{
														"objectId": "CF558FAB-6551-45B6-AB3D-D9050B25F730",
														"kind": "group",
														"name": "openGoogle",
														"originalName": "openGoogle",
														"maskFrame": null,
														"layerFrame": {
															"x": 906,
															"y": 1182,
															"width": 176,
															"height": 27
														},
														"visible": false,
														"metadata": {
															"opacity": 1
														},
														"image": {
															"path": "images/Layer-openGoogle-q0y1nthg.png",
															"frame": {
																"x": 906,
																"y": 1182,
																"width": 176,
																"height": 27
															}
														},
														"children": []
													},
													{
														"objectId": "14AA833B-FA1C-4EE4-9153-850D0FDC6A6D",
														"kind": "group",
														"name": "fileRightOther",
														"originalName": "fileRightOther",
														"maskFrame": null,
														"layerFrame": {
															"x": 865,
															"y": 1098,
															"width": 320,
															"height": 273
														},
														"visible": false,
														"metadata": {
															"opacity": 1
														},
														"children": [
															{
																"objectId": "2BEDA5EC-A7BB-4857-877F-3D586F84CF93",
																"kind": "group",
																"name": "download",
																"originalName": "download",
																"maskFrame": null,
																"layerFrame": {
																	"x": 904,
																	"y": 1219,
																	"width": 107,
																	"height": 15
																},
																"visible": true,
																"metadata": {
																	"opacity": 1
																},
																"image": {
																	"path": "images/Layer-download-mkjfree1.png",
																	"frame": {
																		"x": 904,
																		"y": 1219,
																		"width": 107,
																		"height": 15
																	}
																},
																"children": [
																	{
																		"objectId": "848EDB8C-13F0-44C0-8845-75D61A17C979",
																		"kind": "group",
																		"name": "gizmo_download",
																		"originalName": "gizmo-download",
																		"maskFrame": null,
																		"layerFrame": {
																			"x": 904,
																			"y": 1219,
																			"width": 19,
																			"height": 15
																		},
																		"visible": true,
																		"metadata": {
																			"opacity": 1
																		},
																		"image": {
																			"path": "images/Layer-gizmo_download-odq4rurc.png",
																			"frame": {
																				"x": 904,
																				"y": 1219,
																				"width": 19,
																				"height": 15
																			}
																		},
																		"children": []
																	}
																]
															},
															{
																"objectId": "AFE6D93E-D84C-4AE1-BDF0-57585B9ACCBD",
																"kind": "group",
																"name": "rightContent",
																"originalName": "rightContent",
																"maskFrame": null,
																"layerFrame": {
																	"x": 865,
																	"y": 1098,
																	"width": 319,
																	"height": 273
																},
																"visible": true,
																"metadata": {
																	"opacity": 1
																},
																"image": {
																	"path": "images/Layer-rightContent-quzfnkq5.png",
																	"frame": {
																		"x": 865,
																		"y": 1098,
																		"width": 319,
																		"height": 273
																	}
																},
																"children": [
																	{
																		"objectId": "AAD60B26-D699-4CC6-8938-B283AA1CCB51",
																		"kind": "group",
																		"name": "Group_2",
																		"originalName": "Group 2",
																		"maskFrame": null,
																		"layerFrame": {
																			"x": 905,
																			"y": 1158,
																			"width": 194,
																			"height": 172
																		},
																		"visible": true,
																		"metadata": {
																			"opacity": 1
																		},
																		"image": {
																			"path": "images/Layer-Group_2-qufenjbc.png",
																			"frame": {
																				"x": 905,
																				"y": 1158,
																				"width": 194,
																				"height": 172
																			}
																		},
																		"children": []
																	},
																	{
																		"objectId": "B766B42D-6085-4A83-842E-7AD69FD70F40",
																		"kind": "group",
																		"name": "gizmo_trash",
																		"originalName": "gizmo-trash",
																		"maskFrame": null,
																		"layerFrame": {
																			"x": 906,
																			"y": 1317.0000000000002,
																			"width": 15,
																			"height": 18
																		},
																		"visible": true,
																		"metadata": {
																			"opacity": 1
																		},
																		"image": {
																			"path": "images/Layer-gizmo_trash-qjc2nki0.png",
																			"frame": {
																				"x": 906,
																				"y": 1317.0000000000002,
																				"width": 15,
																				"height": 18
																			}
																		},
																		"children": []
																	},
																	{
																		"objectId": "F2C7DA27-EA1E-499C-B8DC-4F58B8B32AB9",
																		"kind": "group",
																		"name": "gizmo_publication_set",
																		"originalName": "gizmo-publication set",
																		"maskFrame": null,
																		"layerFrame": {
																			"x": 907,
																			"y": 1285,
																			"width": 14,
																			"height": 15
																		},
																		"visible": true,
																		"metadata": {
																			"opacity": 1
																		},
																		"children": [
																			{
																				"objectId": "004CA262-17D4-4CFF-8E2B-2CAF4FA44452",
																				"kind": "group",
																				"name": "Group8",
																				"originalName": "Group",
																				"maskFrame": null,
																				"layerFrame": {
																					"x": 907,
																					"y": 1284.3578124999985,
																					"width": 14,
																					"height": 15
																				},
																				"visible": true,
																				"metadata": {
																					"opacity": 1
																				},
																				"children": [
																					{
																						"objectId": "55123E25-3D4B-4E93-8B7E-76BB6BD72423",
																						"kind": "group",
																						"name": "Production3",
																						"originalName": "Production",
																						"maskFrame": null,
																						"layerFrame": {
																							"x": 907,
																							"y": 1284.3578124999985,
																							"width": 14,
																							"height": 15
																						},
																						"visible": true,
																						"metadata": {
																							"opacity": 1
																						},
																						"children": [
																							{
																								"objectId": "5E648537-3354-4F86-8A8C-0A2B6CC95D72",
																								"kind": "group",
																								"name": "Group9",
																								"originalName": "Group",
																								"maskFrame": null,
																								"layerFrame": {
																									"x": 907.171875,
																									"y": 1285.2953124999985,
																									"width": 14,
																									"height": 14
																								},
																								"visible": true,
																								"metadata": {
																									"opacity": 1
																								},
																								"image": {
																									"path": "images/Layer-Group-nuu2ndg1.png",
																									"frame": {
																										"x": 907.171875,
																										"y": 1285.2953124999985,
																										"width": 14,
																										"height": 14
																									}
																								},
																								"children": []
																							}
																						]
																					},
																					{
																						"objectId": "9CBBAEFA-D8FD-410D-A94A-5EDA1F0E4419",
																						"kind": "group",
																						"name": "_x36_4px_boxes3",
																						"originalName": "_x36_4px_boxes",
																						"maskFrame": null,
																						"layerFrame": {
																							"x": 906,
																							"y": 1284.3578124999985,
																							"width": 15,
																							"height": 15
																						},
																						"visible": true,
																						"metadata": {
																							"opacity": 1
																						},
																						"image": {
																							"path": "images/Layer-_x36_4px_boxes-ouncqkff.png",
																							"frame": {
																								"x": 906,
																								"y": 1284.3578124999985,
																								"width": 15,
																								"height": 15
																							}
																						},
																						"children": []
																					}
																				]
																			}
																		]
																	},
																	{
																		"objectId": "E0133C62-9B99-40F9-8F53-28D058CB5941",
																		"kind": "group",
																		"name": "Document_menu",
																		"originalName": "Document-menu",
																		"maskFrame": null,
																		"layerFrame": {
																			"x": 865,
																			"y": 1098,
																			"width": 319,
																			"height": 273
																		},
																		"visible": true,
																		"metadata": {
																			"opacity": 1
																		},
																		"image": {
																			"path": "images/Layer-Document_menu-rtaxmznd.png",
																			"frame": {
																				"x": 865,
																				"y": 1098,
																				"width": 319,
																				"height": 273
																			}
																		},
																		"children": []
																	}
																]
															}
														]
													}
												]
											},
											{
												"objectId": "EC4DE025-FAD1-40F2-81D7-1C3E9B7D4DE0",
												"kind": "group",
												"name": "documentEdit",
												"originalName": "documentEdit",
												"maskFrame": null,
												"layerFrame": {
													"x": 829,
													"y": 1061,
													"width": 71,
													"height": 88
												},
												"visible": true,
												"metadata": {
													"opacity": 1
												},
												"image": {
													"path": "images/Layer-documentEdit-rum0reuw.png",
													"frame": {
														"x": 829,
														"y": 1061,
														"width": 71,
														"height": 88
													}
												},
												"children": []
											},
											{
												"objectId": "ECD1CDD3-BC73-4BA3-BC3D-239BC7F8F1D1",
												"kind": "group",
												"name": "editorM",
												"originalName": "editorM",
												"maskFrame": null,
												"layerFrame": {
													"x": 785,
													"y": 905,
													"width": 474,
													"height": 311
												},
												"visible": true,
												"metadata": {
													"opacity": 1
												},
												"image": {
													"path": "images/Layer-editorM-runemune.png",
													"frame": {
														"x": 785,
														"y": 905,
														"width": 474,
														"height": 311
													}
												},
												"children": [
													{
														"objectId": "632B3D75-0F4B-40F7-9DCC-1FE2A5BEAE40",
														"kind": "group",
														"name": "gizmo_camera",
														"originalName": "gizmo-camera",
														"maskFrame": null,
														"layerFrame": {
															"x": 1156.000000000001,
															"y": 918.0000000000003,
															"width": 14,
															"height": 14
														},
														"visible": true,
														"metadata": {
															"opacity": 1
														},
														"image": {
															"path": "images/Layer-gizmo_camera-njmyqjne.png",
															"frame": {
																"x": 1156.000000000001,
																"y": 918.0000000000003,
																"width": 14,
																"height": 14
															}
														},
														"children": []
													},
													{
														"objectId": "54B0CC05-7445-49C3-8181-C93348169A26",
														"kind": "group",
														"name": "Paragraph1",
														"originalName": "Paragraph",
														"maskFrame": null,
														"layerFrame": {
															"x": 1059.0000000000005,
															"y": 920.0000000000003,
															"width": 67,
															"height": 9
														},
														"visible": true,
														"metadata": {
															"opacity": 1
														},
														"children": [
															{
																"objectId": "F1A4FD6D-E07A-40C2-AB14-819D8619075E",
																"kind": "group",
																"name": "gizmo_navigate_down3",
																"originalName": "gizmo-navigate-down",
																"maskFrame": null,
																"layerFrame": {
																	"x": 1119.25,
																	"y": 922.2959994040077,
																	"width": 6,
																	"height": 4
																},
																"visible": true,
																"metadata": {
																	"opacity": 1
																},
																"image": {
																	"path": "images/Layer-gizmo_navigate_down-rjfbneze.png",
																	"frame": {
																		"x": 1119.25,
																		"y": 922.2959994040077,
																		"width": 6,
																		"height": 4
																	}
																},
																"children": []
															},
															{
																"objectId": "51DCC48F-DEEE-4897-B279-EF2DF810DEBB",
																"kind": "group",
																"name": "gizmo_list2",
																"originalName": "gizmo-list",
																"maskFrame": null,
																"layerFrame": {
																	"x": 1059.25,
																	"y": 920.2959994040084,
																	"width": 11,
																	"height": 9
																},
																"visible": true,
																"metadata": {
																	"opacity": 1
																},
																"children": [
																	{
																		"objectId": "85E0250B-E796-4001-839B-0A03BC5DD4B4",
																		"kind": "group",
																		"name": "Group10",
																		"originalName": "Group",
																		"maskFrame": null,
																		"layerFrame": {
																			"x": 1059.25,
																			"y": 920.2959994040084,
																			"width": 11,
																			"height": 9
																		},
																		"visible": true,
																		"metadata": {
																			"opacity": 1
																		},
																		"children": [
																			{
																				"objectId": "AEAF3B49-C4B7-45A8-AEAC-A2DB42B20876",
																				"kind": "group",
																				"name": "Production4",
																				"originalName": "Production",
																				"maskFrame": null,
																				"layerFrame": {
																					"x": 1059.2499999999989,
																					"y": 920.2959994040074,
																					"width": 11,
																					"height": 9
																				},
																				"visible": true,
																				"metadata": {
																					"opacity": 1
																				},
																				"children": [
																					{
																						"objectId": "124AE2E7-2502-4A94-B4C2-04CB37AE6D7F",
																						"kind": "group",
																						"name": "Group11",
																						"originalName": "Group",
																						"maskFrame": null,
																						"layerFrame": {
																							"x": 1059.4700520833321,
																							"y": 919.5400336642324,
																							"width": 11,
																							"height": 10
																						},
																						"visible": true,
																						"metadata": {
																							"opacity": 1
																						},
																						"image": {
																							"path": "images/Layer-Group-mti0quuy.png",
																							"frame": {
																								"x": 1059.4700520833321,
																								"y": 919.5400336642324,
																								"width": 11,
																								"height": 10
																							}
																						},
																						"children": []
																					}
																				]
																			},
																			{
																				"objectId": "A03F192D-20D0-47A5-8398-777758AE92AF",
																				"kind": "group",
																				"name": "_x36_4px_boxes4",
																				"originalName": "_x36_4px_boxes",
																				"maskFrame": null,
																				"layerFrame": {
																					"x": 1058.25,
																					"y": 919.2959994040074,
																					"width": 13,
																					"height": 13
																				},
																				"visible": true,
																				"metadata": {
																					"opacity": 1
																				},
																				"image": {
																					"path": "images/Layer-_x36_4px_boxes-qtazrje5.png",
																					"frame": {
																						"x": 1058.25,
																						"y": 919.2959994040074,
																						"width": 13,
																						"height": 13
																					}
																				},
																				"children": []
																			}
																		]
																	}
																]
															},
															{
																"objectId": "C099CB80-E5AF-49C3-A8BB-84BC8CD8471E",
																"kind": "group",
																"name": "gizmo_list3",
																"originalName": "gizmo-list",
																"maskFrame": null,
																"layerFrame": {
																	"x": 1083.2499999999989,
																	"y": 920.2959994040084,
																	"width": 11,
																	"height": 9
																},
																"visible": true,
																"metadata": {
																	"opacity": 1
																},
																"children": [
																	{
																		"objectId": "6DE79A6D-5282-4F28-B8E7-73941B557C7A",
																		"kind": "group",
																		"name": "Group12",
																		"originalName": "Group",
																		"maskFrame": null,
																		"layerFrame": {
																			"x": 1083.0833333333321,
																			"y": 920.2959994040084,
																			"width": 11,
																			"height": 9
																		},
																		"visible": true,
																		"metadata": {
																			"opacity": 1
																		},
																		"children": [
																			{
																				"objectId": "5C2F2F02-3D6F-419F-9348-737BEA728902",
																				"kind": "group",
																				"name": "Production5",
																				"originalName": "Production",
																				"maskFrame": null,
																				"layerFrame": {
																					"x": 1083.0833333333321,
																					"y": 920.2959994040083,
																					"width": 11,
																					"height": 9
																				},
																				"visible": true,
																				"metadata": {
																					"opacity": 1
																				},
																				"children": [
																					{
																						"objectId": "3EEF7DBF-5A27-40C6-B6AD-A1052EF84718",
																						"kind": "group",
																						"name": "Group13",
																						"originalName": "Group",
																						"maskFrame": null,
																						"layerFrame": {
																							"x": 1083.5052083333321,
																							"y": 920.8339557103482,
																							"width": 11,
																							"height": 8
																						},
																						"visible": true,
																						"metadata": {
																							"opacity": 1
																						},
																						"image": {
																							"path": "images/Layer-Group-m0vfrjde.png",
																							"frame": {
																								"x": 1083.5052083333321,
																								"y": 920.8339557103482,
																								"width": 11,
																								"height": 8
																							}
																						},
																						"children": []
																					}
																				]
																			},
																			{
																				"objectId": "B8546B4F-85F8-4025-936A-699E88565A68",
																				"kind": "group",
																				"name": "_x36_4px_boxes5",
																				"originalName": "_x36_4px_boxes",
																				"maskFrame": null,
																				"layerFrame": {
																					"x": 1082.0833333333321,
																					"y": 918.2959994040084,
																					"width": 13,
																					"height": 13
																				},
																				"visible": true,
																				"metadata": {
																					"opacity": 1
																				},
																				"image": {
																					"path": "images/Layer-_x36_4px_boxes-qjg1ndzc.png",
																					"frame": {
																						"x": 1082.0833333333321,
																						"y": 918.2959994040084,
																						"width": 13,
																						"height": 13
																					}
																				},
																				"children": []
																			}
																		]
																	}
																]
															},
															{
																"objectId": "43358647-6468-4BC5-9FFB-7087B38A763A",
																"kind": "group",
																"name": "gizmo_alignment1",
																"originalName": "gizmo-alignment",
																"maskFrame": null,
																"layerFrame": {
																	"x": 1107.2499999999975,
																	"y": 920.2959994040084,
																	"width": 11,
																	"height": 8
																},
																"visible": true,
																"metadata": {
																	"opacity": 1
																},
																"children": [
																	{
																		"objectId": "CF113387-ABEC-4ACA-A1A9-137C4D1D18E4",
																		"kind": "group",
																		"name": "Group14",
																		"originalName": "Group",
																		"maskFrame": null,
																		"layerFrame": {
																			"x": 1106.9166666666642,
																			"y": 920.2959994040084,
																			"width": 11,
																			"height": 8
																		},
																		"visible": true,
																		"metadata": {
																			"opacity": 1
																		},
																		"children": [
																			{
																				"objectId": "0223C1DB-5274-4DCE-95F7-C6F141A8BBA5",
																				"kind": "group",
																				"name": "Production6",
																				"originalName": "Production",
																				"maskFrame": null,
																				"layerFrame": {
																					"x": 1106.9166666666642,
																					"y": 920.2959994040083,
																					"width": 11,
																					"height": 8
																				},
																				"visible": true,
																				"metadata": {
																					"opacity": 1
																				},
																				"children": [
																					{
																						"objectId": "0D047089-4701-4682-8580-07DE3477C454",
																						"kind": "group",
																						"name": "Group15",
																						"originalName": "Group",
																						"maskFrame": null,
																						"layerFrame": {
																							"x": 1107.3385416666642,
																							"y": 920.8339557103482,
																							"width": 11,
																							"height": 8
																						},
																						"visible": true,
																						"metadata": {
																							"opacity": 1
																						},
																						"image": {
																							"path": "images/Layer-Group-meqwndcw.png",
																							"frame": {
																								"x": 1107.3385416666642,
																								"y": 920.8339557103482,
																								"width": 11,
																								"height": 8
																							}
																						},
																						"children": []
																					}
																				]
																			},
																			{
																				"objectId": "072F3937-30F8-45F9-AAA4-2704617A0630",
																				"kind": "group",
																				"name": "_x36_4px_boxes6",
																				"originalName": "_x36_4px_boxes",
																				"maskFrame": null,
																				"layerFrame": {
																					"x": 1105.9166666666642,
																					"y": 918.2959994040084,
																					"width": 14,
																					"height": 13
																				},
																				"visible": true,
																				"metadata": {
																					"opacity": 1
																				},
																				"image": {
																					"path": "images/Layer-_x36_4px_boxes-mdcyrjm5.png",
																					"frame": {
																						"x": 1105.9166666666642,
																						"y": 918.2959994040084,
																						"width": 14,
																						"height": 13
																					}
																				},
																				"children": []
																			}
																		]
																	}
																]
															}
														]
													},
													{
														"objectId": "F11DE68C-F534-47DC-963B-3D384ABC16DE",
														"kind": "group",
														"name": "Font_style1",
														"originalName": "Font style",
														"maskFrame": null,
														"layerFrame": {
															"x": 957.0000000000014,
															"y": 918.9999999999995,
															"width": 67,
															"height": 12
														},
														"visible": true,
														"metadata": {
															"opacity": 1
														},
														"image": {
															"path": "images/Layer-Font_style-rjexreu2.png",
															"frame": {
																"x": 957.0000000000014,
																"y": 918.9999999999995,
																"width": 67,
																"height": 12
															}
														},
														"children": [
															{
																"objectId": "05329995-50D3-48AB-9B9E-81BCECB7C4F0",
																"kind": "group",
																"name": "gizmo_pencel1",
																"originalName": "gizmo-pencel",
																"maskFrame": null,
																"layerFrame": {
																	"x": 1011.4166666666681,
																	"y": 919.2547865603807,
																	"width": 12,
																	"height": 12
																},
																"visible": true,
																"metadata": {
																	"opacity": 1
																},
																"image": {
																	"path": "images/Layer-gizmo_pencel-mduzmjk5.png",
																	"frame": {
																		"x": 1011.4166666666681,
																		"y": 919.2547865603807,
																		"width": 12,
																		"height": 12
																	}
																},
																"children": []
															}
														]
													},
													{
														"objectId": "4DF8F56A-1F13-4BC7-8158-028C8225B031",
														"kind": "group",
														"name": "Font1",
														"originalName": "Font",
														"maskFrame": null,
														"layerFrame": {
															"x": 835.0000000000014,
															"y": 921.9999999999993,
															"width": 90,
															"height": 9
														},
														"visible": true,
														"metadata": {
															"opacity": 1
														},
														"image": {
															"path": "images/Layer-Font-nergoey1.png",
															"frame": {
																"x": 835.0000000000014,
																"y": 921.9999999999993,
																"width": 90,
																"height": 9
															}
														},
														"children": [
															{
																"objectId": "AC1011DA-4FEB-44C7-A4D2-B777EC3E748E",
																"kind": "group",
																"name": "gizmo_navigate_down4",
																"originalName": "gizmo-navigate-down",
																"maskFrame": null,
																"layerFrame": {
																	"x": 917.9166666666667,
																	"y": 924.337212247634,
																	"width": 7,
																	"height": 5
																},
																"visible": true,
																"metadata": {
																	"opacity": 1
																},
																"image": {
																	"path": "images/Layer-gizmo_navigate_down-qumxmdex.png",
																	"frame": {
																		"x": 917.9166666666667,
																		"y": 924.337212247634,
																		"width": 7,
																		"height": 5
																	}
																},
																"children": []
															},
															{
																"objectId": "93BE6FF4-4DB2-47C3-B468-B6F6ACF98094",
																"kind": "group",
																"name": "gizmo_navigate_down5",
																"originalName": "gizmo-navigate-down",
																"maskFrame": null,
																"layerFrame": {
																	"x": 882.9166666666655,
																	"y": 925.3372122476349,
																	"width": 8,
																	"height": 5
																},
																"visible": true,
																"metadata": {
																	"opacity": 1
																},
																"image": {
																	"path": "images/Layer-gizmo_navigate_down-otncrtzg.png",
																	"frame": {
																		"x": 882.9166666666655,
																		"y": 925.3372122476349,
																		"width": 8,
																		"height": 5
																	}
																},
																"children": []
															}
														]
													}
												]
											},
											{
												"objectId": "7F9CEA2D-5928-4242-AB94-F1AE19CAE5DA",
												"kind": "group",
												"name": "otherMeetingBS",
												"originalName": "otherMeetingBS",
												"maskFrame": null,
												"layerFrame": {
													"x": 754,
													"y": 811,
													"width": 541,
													"height": 444
												},
												"visible": true,
												"metadata": {
													"opacity": 1
												},
												"image": {
													"path": "images/Layer-otherMeetingBS-n0y5q0vb.png",
													"frame": {
														"x": 754,
														"y": 811,
														"width": 541,
														"height": 444
													}
												},
												"children": []
											}
										]
									}
								]
							},
							{
								"objectId": "36DA159E-2A59-45A9-9547-291A736231CD",
								"kind": "group",
								"name": "resultBox",
								"originalName": "resultBox",
								"maskFrame": null,
								"layerFrame": {
									"x": 627,
									"y": 805,
									"width": 395,
									"height": 94
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"children": [
									{
										"objectId": "A62CCE6D-9DA6-4F1E-9D86-F1026E5F7F0A",
										"kind": "group",
										"name": "btn_boxOpen",
										"originalName": "btn_boxOpen",
										"maskFrame": null,
										"layerFrame": {
											"x": 993,
											"y": 825,
											"width": 13,
											"height": 9
										},
										"visible": true,
										"metadata": {
											"opacity": 1
										},
										"image": {
											"path": "images/Layer-btn_boxOpen-qtyyq0nf.png",
											"frame": {
												"x": 993,
												"y": 825,
												"width": 13,
												"height": 9
											}
										},
										"children": []
									},
									{
										"objectId": "A06E8599-F994-4065-A798-CCACB99B939C",
										"kind": "group",
										"name": "attachment",
										"originalName": "attachment",
										"maskFrame": null,
										"layerFrame": {
											"x": 978,
											"y": 864,
											"width": 25,
											"height": 16
										},
										"visible": true,
										"metadata": {
											"opacity": 1
										},
										"children": [
											{
												"objectId": "22237E4C-C24E-4363-824B-FF450CBA61B8",
												"kind": "group",
												"name": "openDocument",
												"originalName": "openDocument",
												"maskFrame": null,
												"layerFrame": {
													"x": 978,
													"y": 864,
													"width": 25,
													"height": 16
												},
												"visible": true,
												"metadata": {
													"opacity": 1
												},
												"image": {
													"path": "images/Layer-openDocument-mjiymzdf.png",
													"frame": {
														"x": 978,
														"y": 864,
														"width": 25,
														"height": 16
													}
												},
												"children": []
											}
										]
									},
									{
										"objectId": "D8089B98-9113-492B-9054-5D94A5FFD7E5",
										"kind": "group",
										"name": "Group_21",
										"originalName": "Group 2",
										"maskFrame": null,
										"layerFrame": {
											"x": 627,
											"y": 805,
											"width": 395,
											"height": 94
										},
										"visible": true,
										"metadata": {
											"opacity": 1
										},
										"image": {
											"path": "images/Layer-Group_2-rdgwodlc.png",
											"frame": {
												"x": 627,
												"y": 805,
												"width": 395,
												"height": 94
											}
										},
										"children": [
											{
												"objectId": "C99BBE25-E816-47F6-8389-8041159F7B00",
												"kind": "group",
												"name": "firstDiscussion1",
												"originalName": "firstDiscussion",
												"maskFrame": null,
												"layerFrame": {
													"x": 754,
													"y": 811,
													"width": 268,
													"height": 88
												},
												"visible": true,
												"metadata": {
													"opacity": 1
												},
												"image": {
													"path": "images/Layer-firstDiscussion-qzk5qkjf.png",
													"frame": {
														"x": 754,
														"y": 811,
														"width": 268,
														"height": 88
													}
												},
												"children": []
											}
										]
									}
								]
							},
							{
								"objectId": "8AFBFDAA-260C-477F-9489-A9F8BB0E995E",
								"kind": "group",
								"name": "experimentBox",
								"originalName": "experimentBox",
								"maskFrame": null,
								"layerFrame": {
									"x": 627,
									"y": 1073,
									"width": 395,
									"height": 94
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-experimentBox-oefgqkze.png",
									"frame": {
										"x": 627,
										"y": 1073,
										"width": 395,
										"height": 94
									}
								},
								"children": [
									{
										"objectId": "0D0DAA0A-C169-480E-A57F-F9F2C19AAB66",
										"kind": "group",
										"name": "firstDiscussion2",
										"originalName": "firstDiscussion",
										"maskFrame": null,
										"layerFrame": {
											"x": 754,
											"y": 1079,
											"width": 268,
											"height": 88
										},
										"visible": true,
										"metadata": {
											"opacity": 1
										},
										"image": {
											"path": "images/Layer-firstDiscussion-meqwrefb.png",
											"frame": {
												"x": 754,
												"y": 1079,
												"width": 268,
												"height": 88
											}
										},
										"children": [
											{
												"objectId": "43C941E2-492A-4F86-993E-7D0DAEA7F84E",
												"kind": "group",
												"name": "openBox3",
												"originalName": "openBox3",
												"maskFrame": null,
												"layerFrame": {
													"x": 993,
													"y": 1093,
													"width": 13,
													"height": 9
												},
												"visible": true,
												"metadata": {
													"opacity": 1
												},
												"image": {
													"path": "images/Layer-openBox3-ndndotqx.png",
													"frame": {
														"x": 993,
														"y": 1093,
														"width": 13,
														"height": 9
													}
												},
												"children": []
											}
										]
									}
								]
							},
							{
								"objectId": "BD6988D4-ABB0-4385-9812-706EB1513BD1",
								"kind": "group",
								"name": "line",
								"originalName": "line",
								"maskFrame": null,
								"layerFrame": {
									"x": 721,
									"y": 754,
									"width": 2,
									"height": 413
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-line-qkq2otg4.png",
									"frame": {
										"x": 721,
										"y": 754,
										"width": 2,
										"height": 413
									}
								},
								"children": []
							}
						]
					},
					{
						"objectId": "B6C45BAE-34EC-4E1D-AB6E-FBE43179315E",
						"kind": "text",
						"name": "overview5",
						"originalName": "overview5",
						"maskFrame": null,
						"layerFrame": {
							"x": 230,
							"y": 357,
							"width": 76,
							"height": 16
						},
						"visible": true,
						"metadata": {
							"opacity": 1,
							"string": "Overview",
							"css": [
								"/* Overview: */",
								"opacity: 0.5;",
								"font-family: .HelveticaNeueDeskInterface-Regular;",
								"font-size: 18px;",
								"color: #000000;",
								"letter-spacing: 0;"
							]
						},
						"image": {
							"path": "images/Layer-overview5-qjzdndvc.png",
							"frame": {
								"x": 230,
								"y": 357,
								"width": 76,
								"height": 16
							}
						},
						"children": []
					},
					{
						"objectId": "EFDF8DA1-0E8E-4B96-BF6B-B074BB764ED0",
						"kind": "text",
						"name": "mentorInGroup",
						"originalName": "mentorInGroup",
						"maskFrame": null,
						"layerFrame": {
							"x": 555,
							"y": 241,
							"width": 84,
							"height": 16
						},
						"visible": true,
						"metadata": {
							"opacity": 1,
							"string": "Seth Bush",
							"css": [
								"/* Seth Bush: */",
								"font-family: .HelveticaNeueDeskInterface-Regular;",
								"font-size: 18px;",
								"color: #499DB7;",
								"letter-spacing: 0;"
							]
						},
						"image": {
							"path": "images/Layer-mentorInGroup-ruzerjhe.png",
							"frame": {
								"x": 555,
								"y": 241,
								"width": 84,
								"height": 16
							}
						},
						"children": []
					},
					{
						"objectId": "10A5F2AB-AD0D-40BD-9009-DD62EE3A0243",
						"kind": "group",
						"name": "header5",
						"originalName": "header5*",
						"maskFrame": null,
						"layerFrame": {
							"x": -1,
							"y": -2,
							"width": 1442,
							"height": 407
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-header5-mtbbnuyy.jpg",
							"frame": {
								"x": -1,
								"y": -2,
								"width": 1442,
								"height": 407
							}
						},
						"children": []
					},
					{
						"objectId": "3BB28EC3-B5AA-4772-9220-2C92D89B57DA",
						"kind": "group",
						"name": "bg1",
						"originalName": "bg",
						"maskFrame": null,
						"layerFrame": {
							"x": 226,
							"y": 735,
							"width": 992,
							"height": 619
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-bg-m0jcmjhf.png",
							"frame": {
								"x": 226,
								"y": 735,
								"width": 992,
								"height": 619
							}
						},
						"children": []
					},
					{
						"objectId": "5A24B6FA-DCFF-44C7-9116-7E9451E885EC",
						"kind": "group",
						"name": "topNR",
						"originalName": "topNR",
						"maskFrame": null,
						"layerFrame": {
							"x": 224,
							"y": 474,
							"width": 995,
							"height": 375
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-topNR-nueynei2.png",
							"frame": {
								"x": 224,
								"y": 474,
								"width": 995,
								"height": 375
							}
						},
						"children": [
							{
								"objectId": "47DE9F5B-79ED-4900-A164-0C56620485C1",
								"kind": "group",
								"name": "Group16",
								"originalName": "Group",
								"maskFrame": null,
								"layerFrame": {
									"x": 804,
									"y": 559,
									"width": 175,
									"height": 136
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-Group-nddertlg.png",
									"frame": {
										"x": 804,
										"y": 559,
										"width": 175,
										"height": 136
									}
								},
								"children": []
							},
							{
								"objectId": "4603F572-EA3A-4F00-8AA0-26B36C57446E",
								"kind": "group",
								"name": "Group17",
								"originalName": "Group",
								"maskFrame": null,
								"layerFrame": {
									"x": 463,
									"y": 559,
									"width": 174,
									"height": 136
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-Group-ndywm0y1.png",
									"frame": {
										"x": 463,
										"y": 559,
										"width": 174,
										"height": 136
									}
								},
								"children": []
							}
						]
					},
					{
						"objectId": "401D35A0-62A7-4CAD-BD37-581748582A59",
						"kind": "group",
						"name": "bg2",
						"originalName": "bg*",
						"maskFrame": null,
						"layerFrame": {
							"x": 2,
							"y": 798,
							"width": 1440,
							"height": 660
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-bg-ndaxrdm1.png",
							"frame": {
								"x": 2,
								"y": 798,
								"width": 1440,
								"height": 660
							}
						},
						"children": []
					}
				]
			}
		]
	}
]